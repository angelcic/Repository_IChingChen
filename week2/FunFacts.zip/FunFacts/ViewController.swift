//
//  ViewController.swift
//  FunFacts
//
//  Created by iching chen on 2019/6/20.
//  Copyright © 2019 ichingchen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var funFactLabel: UILabel!
    @IBOutlet weak var funFactButton: UIButton!
    @IBOutlet weak var assignmentLabel: UILabel!
    
    let factProvider = FactProvider()
    let colorProvider = BackgroundColorProvider()
    let assignmentProvider = AssignmentProvider()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        funFactLabel.text = factProvider.randomFact()
        assignmentLabel.text = assignmentProvider.ramdomAssignment()
    }
    
    @IBAction func showFact() {
        funFactLabel.text = factProvider.randomFact()
        let randomColor = colorProvider.ramdomColor()
        view.backgroundColor = randomColor
        funFactButton.tintColor = randomColor
        assignmentLabel.text = assignmentProvider.ramdomAssignment()
    }
    
}

